# Rock Paper Scissors Game
Fully Functional Rock Paper Scissors Game in Python

This Game comes in 4 modes:

1) Beginner
2) Intermediate
3) Expert
4) Super Hard

Beginner is only doing it randomly. Intermediate uses a particular AI Algorithm based on common player psychology. Expert uses a butchering of the Markov Chain Concept to allow the Machine to adapt to player strategies and accurately predict their next pick. Super hard is well... Super hard.

FYI: I added the AI Algorithm bot code and Markov Chain Bot code seperately if you want to test them out with an individual tester (that I will also upload). I also included a battle of the bots where I pit the AI bot (bot 1) and the Markov Chain Bot (bot 2) against each other.

Look out for an easter egg btw... BAZINGA!!!
